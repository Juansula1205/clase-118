# PRO_C118_AM3_V1
IMPLEMENTACIÓN DE APLICACIÓN WEB: Diario digital  
Python. Flask. jQuery.  
  
Plan de la clase.  
Código de referencia  
  
### Texto en inglés: PRO-C118-Reference-Code
